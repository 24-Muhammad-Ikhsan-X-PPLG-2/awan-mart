import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
export const finish = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: finish.url(options),
    method: 'get',
})

finish.definition = {
    methods: ["get","head"],
    url: '/payment/finish',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finish.url = (options?: RouteQueryOptions) => {
    return finish.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finish.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: finish.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finish.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: finish.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
const finishForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: finish.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finishForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: finish.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finishForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: finish.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

finish.form = finishForm

const payment = {
    finish: Object.assign(finish, finish),
}

export default payment