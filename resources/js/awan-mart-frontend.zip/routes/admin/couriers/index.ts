import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/couriers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::index
* @see app/Http/Controllers/AdminCourierController.php:18
* @route '/admin/couriers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/couriers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::create
* @see app/Http/Controllers/AdminCourierController.php:67
* @route '/admin/couriers/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\AdminCourierController::store
* @see app/Http/Controllers/AdminCourierController.php:93
* @route '/admin/couriers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/couriers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminCourierController::store
* @see app/Http/Controllers/AdminCourierController.php:93
* @route '/admin/couriers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCourierController::store
* @see app/Http/Controllers/AdminCourierController.php:93
* @route '/admin/couriers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCourierController::store
* @see app/Http/Controllers/AdminCourierController.php:93
* @route '/admin/couriers'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCourierController::store
* @see app/Http/Controllers/AdminCourierController.php:93
* @route '/admin/couriers'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
export const edit = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/couriers/{courier}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
edit.url = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { courier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            courier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        courier: typeof args.courier === 'object'
        ? args.courier.id
        : args.courier,
    }

    return edit.definition.url
            .replace('{courier}', parsedArgs.courier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
edit.get = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
edit.head = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
const editForm = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
editForm.get = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCourierController::edit
* @see app/Http/Controllers/AdminCourierController.php:76
* @route '/admin/couriers/{courier}/edit'
*/
editForm.head = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\AdminCourierController::update
* @see app/Http/Controllers/AdminCourierController.php:101
* @route '/admin/couriers/{courier}'
*/
export const update = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/couriers/{courier}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminCourierController::update
* @see app/Http/Controllers/AdminCourierController.php:101
* @route '/admin/couriers/{courier}'
*/
update.url = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { courier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            courier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        courier: typeof args.courier === 'object'
        ? args.courier.id
        : args.courier,
    }

    return update.definition.url
            .replace('{courier}', parsedArgs.courier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCourierController::update
* @see app/Http/Controllers/AdminCourierController.php:101
* @route '/admin/couriers/{courier}'
*/
update.put = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AdminCourierController::update
* @see app/Http/Controllers/AdminCourierController.php:101
* @route '/admin/couriers/{courier}'
*/
const updateForm = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCourierController::update
* @see app/Http/Controllers/AdminCourierController.php:101
* @route '/admin/couriers/{courier}'
*/
updateForm.put = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\AdminCourierController::destroy
* @see app/Http/Controllers/AdminCourierController.php:108
* @route '/admin/couriers/{courier}'
*/
export const destroy = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/couriers/{courier}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminCourierController::destroy
* @see app/Http/Controllers/AdminCourierController.php:108
* @route '/admin/couriers/{courier}'
*/
destroy.url = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { courier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            courier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        courier: typeof args.courier === 'object'
        ? args.courier.id
        : args.courier,
    }

    return destroy.definition.url
            .replace('{courier}', parsedArgs.courier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCourierController::destroy
* @see app/Http/Controllers/AdminCourierController.php:108
* @route '/admin/couriers/{courier}'
*/
destroy.delete = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\AdminCourierController::destroy
* @see app/Http/Controllers/AdminCourierController.php:108
* @route '/admin/couriers/{courier}'
*/
const destroyForm = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCourierController::destroy
* @see app/Http/Controllers/AdminCourierController.php:108
* @route '/admin/couriers/{courier}'
*/
destroyForm.delete = (args: { courier: number | { id: number } } | [courier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const couriers = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default couriers