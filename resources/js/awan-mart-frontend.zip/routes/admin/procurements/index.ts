import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/procurements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::index
* @see app/Http/Controllers/AdminProcurementController.php:34
* @route '/admin/procurements'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/procurements/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::create
* @see app/Http/Controllers/AdminProcurementController.php:125
* @route '/admin/procurements/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
export const options = (routeOptions?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: options.url(routeOptions),
    method: 'get',
})

options.definition = {
    methods: ["get","head"],
    url: '/admin/procurements/options',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
options.url = (routeOptions?: RouteQueryOptions) => {
    return options.definition.url
    + queryParams(routeOptions)
}

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
options.get = (routeOptions?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: options.url(routeOptions),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
options.head = (routeOptions?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: options.url(routeOptions),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
const optionsForm = (routeOptions?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: options.url(

    routeOptions
   ),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
optionsForm.get = (routeOptions?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: options.url(

    routeOptions
   ),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::options
* @see app/Http/Controllers/AdminProcurementController.php:138
* @route '/admin/procurements/options'
*/
optionsForm.head = (routeOptions?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: options.url({
        [routeOptions?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(routeOptions?.query ?? routeOptions?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

options.form = optionsForm

/**
* @see \App\Http\Controllers\AdminProcurementController::store
* @see app/Http/Controllers/AdminProcurementController.php:156
* @route '/admin/procurements'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/procurements',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminProcurementController::store
* @see app/Http/Controllers/AdminProcurementController.php:156
* @route '/admin/procurements'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProcurementController::store
* @see app/Http/Controllers/AdminProcurementController.php:156
* @route '/admin/procurements'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::store
* @see app/Http/Controllers/AdminProcurementController.php:156
* @route '/admin/procurements'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::store
* @see app/Http/Controllers/AdminProcurementController.php:156
* @route '/admin/procurements'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
export const show = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/procurements/{procurement}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
show.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { procurement: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            procurement: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        procurement: typeof args.procurement === 'object'
        ? args.procurement.id
        : args.procurement,
    }

    return show.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
show.get = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
show.head = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
const showForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
showForm.get = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::show
* @see app/Http/Controllers/AdminProcurementController.php:234
* @route '/admin/procurements/{procurement}'
*/
showForm.head = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\AdminProcurementController::updateStatus
* @see app/Http/Controllers/AdminProcurementController.php:299
* @route '/admin/procurements/{procurement}/status'
*/
export const updateStatus = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/admin/procurements/{procurement}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminProcurementController::updateStatus
* @see app/Http/Controllers/AdminProcurementController.php:299
* @route '/admin/procurements/{procurement}/status'
*/
updateStatus.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { procurement: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            procurement: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        procurement: typeof args.procurement === 'object'
        ? args.procurement.id
        : args.procurement,
    }

    return updateStatus.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProcurementController::updateStatus
* @see app/Http/Controllers/AdminProcurementController.php:299
* @route '/admin/procurements/{procurement}/status'
*/
updateStatus.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::updateStatus
* @see app/Http/Controllers/AdminProcurementController.php:299
* @route '/admin/procurements/{procurement}/status'
*/
const updateStatusForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminProcurementController::updateStatus
* @see app/Http/Controllers/AdminProcurementController.php:299
* @route '/admin/procurements/{procurement}/status'
*/
updateStatusForm.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateStatus.form = updateStatusForm

const procurements = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    options: Object.assign(options, options),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    updateStatus: Object.assign(updateStatus, updateStatus),
}

export default procurements