import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/supplier/deliveries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierDeliveryController::index
* @see app/Http/Controllers/SupplierDeliveryController.php:19
* @route '/supplier/deliveries'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\SupplierDeliveryController::complete
* @see app/Http/Controllers/SupplierDeliveryController.php:78
* @route '/supplier/deliveries/{order}/complete'
*/
export const complete = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

complete.definition = {
    methods: ["patch"],
    url: '/supplier/deliveries/{order}/complete',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SupplierDeliveryController::complete
* @see app/Http/Controllers/SupplierDeliveryController.php:78
* @route '/supplier/deliveries/{order}/complete'
*/
complete.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return complete.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierDeliveryController::complete
* @see app/Http/Controllers/SupplierDeliveryController.php:78
* @route '/supplier/deliveries/{order}/complete'
*/
complete.patch = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\SupplierDeliveryController::complete
* @see app/Http/Controllers/SupplierDeliveryController.php:78
* @route '/supplier/deliveries/{order}/complete'
*/
const completeForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SupplierDeliveryController::complete
* @see app/Http/Controllers/SupplierDeliveryController.php:78
* @route '/supplier/deliveries/{order}/complete'
*/
completeForm.patch = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

complete.form = completeForm

const deliveries = {
    index: Object.assign(index, index),
    complete: Object.assign(complete, complete),
}

export default deliveries