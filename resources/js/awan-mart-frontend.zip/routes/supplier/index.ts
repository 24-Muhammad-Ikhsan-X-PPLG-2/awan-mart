import deliveries from './deliveries'
import procurements from './procurements'

const supplier = {
    deliveries: Object.assign(deliveries, deliveries),
    procurements: Object.assign(procurements, procurements),
}

export default supplier