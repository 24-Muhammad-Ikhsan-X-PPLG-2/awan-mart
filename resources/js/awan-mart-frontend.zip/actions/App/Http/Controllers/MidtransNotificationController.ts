import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MidtransNotificationController::__invoke
* @see app/Http/Controllers/MidtransNotificationController.php:23
* @route '/payment/notification'
*/
const MidtransNotificationController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: MidtransNotificationController.url(options),
    method: 'post',
})

MidtransNotificationController.definition = {
    methods: ["post"],
    url: '/payment/notification',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MidtransNotificationController::__invoke
* @see app/Http/Controllers/MidtransNotificationController.php:23
* @route '/payment/notification'
*/
MidtransNotificationController.url = (options?: RouteQueryOptions) => {
    return MidtransNotificationController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MidtransNotificationController::__invoke
* @see app/Http/Controllers/MidtransNotificationController.php:23
* @route '/payment/notification'
*/
MidtransNotificationController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: MidtransNotificationController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MidtransNotificationController::__invoke
* @see app/Http/Controllers/MidtransNotificationController.php:23
* @route '/payment/notification'
*/
const MidtransNotificationControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: MidtransNotificationController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MidtransNotificationController::__invoke
* @see app/Http/Controllers/MidtransNotificationController.php:23
* @route '/payment/notification'
*/
MidtransNotificationControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: MidtransNotificationController.url(options),
    method: 'post',
})

MidtransNotificationController.form = MidtransNotificationControllerForm

export default MidtransNotificationController