import HomeController from './HomeController'
import ProductsController from './ProductsController'
import CategoryController from './CategoryController'
import MidtransNotificationController from './MidtransNotificationController'
import AuthController from './AuthController'
import CartController from './CartController'
import CheckoutController from './CheckoutController'
import UserController from './UserController'
import ReviewController from './ReviewController'
import DashboardController from './DashboardController'
import AdminCatalogController from './AdminCatalogController'
import AdminSupplierController from './AdminSupplierController'
import AdminCourierController from './AdminCourierController'
import AdminOrderController from './AdminOrderController'
import AdminProcurementController from './AdminProcurementController'
import SupplierDeliveryController from './SupplierDeliveryController'
import SupplierProcurementController from './SupplierProcurementController'

const Controllers = {
    HomeController: Object.assign(HomeController, HomeController),
    ProductsController: Object.assign(ProductsController, ProductsController),
    CategoryController: Object.assign(CategoryController, CategoryController),
    MidtransNotificationController: Object.assign(MidtransNotificationController, MidtransNotificationController),
    AuthController: Object.assign(AuthController, AuthController),
    CartController: Object.assign(CartController, CartController),
    CheckoutController: Object.assign(CheckoutController, CheckoutController),
    UserController: Object.assign(UserController, UserController),
    ReviewController: Object.assign(ReviewController, ReviewController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    AdminCatalogController: Object.assign(AdminCatalogController, AdminCatalogController),
    AdminSupplierController: Object.assign(AdminSupplierController, AdminSupplierController),
    AdminCourierController: Object.assign(AdminCourierController, AdminCourierController),
    AdminOrderController: Object.assign(AdminOrderController, AdminOrderController),
    AdminProcurementController: Object.assign(AdminProcurementController, AdminProcurementController),
    SupplierDeliveryController: Object.assign(SupplierDeliveryController, SupplierDeliveryController),
    SupplierProcurementController: Object.assign(SupplierProcurementController, SupplierProcurementController),
}

export default Controllers