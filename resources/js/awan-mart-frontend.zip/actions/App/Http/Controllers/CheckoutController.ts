import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CheckoutController::index
* @see app/Http/Controllers/CheckoutController.php:38
* @route '/checkout'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: index.url(options),
    method: 'post',
})

index.definition = {
    methods: ["post"],
    url: '/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CheckoutController::index
* @see app/Http/Controllers/CheckoutController.php:38
* @route '/checkout'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::index
* @see app/Http/Controllers/CheckoutController.php:38
* @route '/checkout'
*/
index.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: index.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::index
* @see app/Http/Controllers/CheckoutController.php:38
* @route '/checkout'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: index.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::index
* @see app/Http/Controllers/CheckoutController.php:38
* @route '/checkout'
*/
indexForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: index.url(options),
    method: 'post',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\CheckoutController::store
* @see app/Http/Controllers/CheckoutController.php:99
* @route '/checkout/store'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/checkout/store',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CheckoutController::store
* @see app/Http/Controllers/CheckoutController.php:99
* @route '/checkout/store'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::store
* @see app/Http/Controllers/CheckoutController.php:99
* @route '/checkout/store'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::store
* @see app/Http/Controllers/CheckoutController.php:99
* @route '/checkout/store'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::store
* @see app/Http/Controllers/CheckoutController.php:99
* @route '/checkout/store'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\CheckoutController::confirmPayment
* @see app/Http/Controllers/CheckoutController.php:393
* @route '/checkout/confirm-payment'
*/
export const confirmPayment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmPayment.url(options),
    method: 'post',
})

confirmPayment.definition = {
    methods: ["post"],
    url: '/checkout/confirm-payment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CheckoutController::confirmPayment
* @see app/Http/Controllers/CheckoutController.php:393
* @route '/checkout/confirm-payment'
*/
confirmPayment.url = (options?: RouteQueryOptions) => {
    return confirmPayment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::confirmPayment
* @see app/Http/Controllers/CheckoutController.php:393
* @route '/checkout/confirm-payment'
*/
confirmPayment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmPayment.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::confirmPayment
* @see app/Http/Controllers/CheckoutController.php:393
* @route '/checkout/confirm-payment'
*/
const confirmPaymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: confirmPayment.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::confirmPayment
* @see app/Http/Controllers/CheckoutController.php:393
* @route '/checkout/confirm-payment'
*/
confirmPaymentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: confirmPayment.url(options),
    method: 'post',
})

confirmPayment.form = confirmPaymentForm

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
export const pendingPayment = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingPayment.url(args, options),
    method: 'get',
})

pendingPayment.definition = {
    methods: ["get","head"],
    url: '/checkout/payment/{orderNumber}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
pendingPayment.url = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderNumber: args }
    }

    if (Array.isArray(args)) {
        args = {
            orderNumber: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderNumber: args.orderNumber,
    }

    return pendingPayment.definition.url
            .replace('{orderNumber}', parsedArgs.orderNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
pendingPayment.get = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingPayment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
pendingPayment.head = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pendingPayment.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
const pendingPaymentForm = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendingPayment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
pendingPaymentForm.get = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendingPayment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::pendingPayment
* @see app/Http/Controllers/CheckoutController.php:450
* @route '/checkout/payment/{orderNumber}'
*/
pendingPaymentForm.head = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendingPayment.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pendingPayment.form = pendingPaymentForm

/**
* @see \App\Http\Controllers\CheckoutController::cancelPayment
* @see app/Http/Controllers/CheckoutController.php:523
* @route '/checkout/payment/{orderNumber}/cancel'
*/
export const cancelPayment = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancelPayment.url(args, options),
    method: 'post',
})

cancelPayment.definition = {
    methods: ["post"],
    url: '/checkout/payment/{orderNumber}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CheckoutController::cancelPayment
* @see app/Http/Controllers/CheckoutController.php:523
* @route '/checkout/payment/{orderNumber}/cancel'
*/
cancelPayment.url = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderNumber: args }
    }

    if (Array.isArray(args)) {
        args = {
            orderNumber: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderNumber: args.orderNumber,
    }

    return cancelPayment.definition.url
            .replace('{orderNumber}', parsedArgs.orderNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::cancelPayment
* @see app/Http/Controllers/CheckoutController.php:523
* @route '/checkout/payment/{orderNumber}/cancel'
*/
cancelPayment.post = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancelPayment.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::cancelPayment
* @see app/Http/Controllers/CheckoutController.php:523
* @route '/checkout/payment/{orderNumber}/cancel'
*/
const cancelPaymentForm = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancelPayment.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CheckoutController::cancelPayment
* @see app/Http/Controllers/CheckoutController.php:523
* @route '/checkout/payment/{orderNumber}/cancel'
*/
cancelPaymentForm.post = (args: { orderNumber: string | number } | [orderNumber: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancelPayment.url(args, options),
    method: 'post',
})

cancelPayment.form = cancelPaymentForm

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
export const finish = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: finish.url(options),
    method: 'get',
})

finish.definition = {
    methods: ["get","head"],
    url: '/payment/finish',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finish.url = (options?: RouteQueryOptions) => {
    return finish.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finish.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: finish.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finish.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: finish.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
const finishForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: finish.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finishForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: finish.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CheckoutController::finish
* @see app/Http/Controllers/CheckoutController.php:475
* @route '/payment/finish'
*/
finishForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: finish.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

finish.form = finishForm

const CheckoutController = { index, store, confirmPayment, pendingPayment, cancelPayment, finish }

export default CheckoutController