import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
export const loginView = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loginView.url(options),
    method: 'get',
})

loginView.definition = {
    methods: ["get","head"],
    url: '/auth/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
loginView.url = (options?: RouteQueryOptions) => {
    return loginView.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
loginView.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loginView.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
loginView.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loginView.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
const loginViewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loginView.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
loginViewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loginView.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::loginView
* @see app/Http/Controllers/AuthController.php:23
* @route '/auth/login'
*/
loginViewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: loginView.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

loginView.form = loginViewForm

/**
* @see \App\Http\Controllers\AuthController::login
* @see app/Http/Controllers/AuthController.php:42
* @route '/auth/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/auth/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::login
* @see app/Http/Controllers/AuthController.php:42
* @route '/auth/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::login
* @see app/Http/Controllers/AuthController.php:42
* @route '/auth/login'
*/
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AuthController::login
* @see app/Http/Controllers/AuthController.php:42
* @route '/auth/login'
*/
const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AuthController::login
* @see app/Http/Controllers/AuthController.php:42
* @route '/auth/login'
*/
loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: login.url(options),
    method: 'post',
})

login.form = loginForm

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
export const registerView = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: registerView.url(options),
    method: 'get',
})

registerView.definition = {
    methods: ["get","head"],
    url: '/auth/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
registerView.url = (options?: RouteQueryOptions) => {
    return registerView.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
registerView.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: registerView.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
registerView.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: registerView.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
const registerViewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: registerView.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
registerViewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: registerView.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::registerView
* @see app/Http/Controllers/AuthController.php:31
* @route '/auth/register'
*/
registerViewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: registerView.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

registerView.form = registerViewForm

/**
* @see \App\Http\Controllers\AuthController::register
* @see app/Http/Controllers/AuthController.php:82
* @route '/auth/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/auth/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::register
* @see app/Http/Controllers/AuthController.php:82
* @route '/auth/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::register
* @see app/Http/Controllers/AuthController.php:82
* @route '/auth/register'
*/
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AuthController::register
* @see app/Http/Controllers/AuthController.php:82
* @route '/auth/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AuthController::register
* @see app/Http/Controllers/AuthController.php:82
* @route '/auth/register'
*/
registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: register.url(options),
    method: 'post',
})

register.form = registerForm

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logout.url(options),
    method: 'get',
})

logout.definition = {
    methods: ["get","head"],
    url: '/auth/logout',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
logout.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logout.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
logout.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logout.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logout.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
logoutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logout.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AuthController::logout
* @see app/Http/Controllers/AuthController.php:131
* @route '/auth/logout'
*/
logoutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logout.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

logout.form = logoutForm

const AuthController = { loginView, login, registerView, register, logout }

export default AuthController