import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/supplier/procurements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::index
* @see app/Http/Controllers/SupplierProcurementController.php:31
* @route '/supplier/procurements'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
export const show = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/supplier/procurements/{procurement}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
show.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { procurement: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            procurement: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        procurement: typeof args.procurement === 'object'
        ? args.procurement.id
        : args.procurement,
    }

    return show.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
show.get = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
show.head = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
const showForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
showForm.get = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::show
* @see app/Http/Controllers/SupplierProcurementController.php:112
* @route '/supplier/procurements/{procurement}'
*/
showForm.head = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\SupplierProcurementController::accept
* @see app/Http/Controllers/SupplierProcurementController.php:157
* @route '/supplier/procurements/{procurement}/accept'
*/
export const accept = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

accept.definition = {
    methods: ["patch"],
    url: '/supplier/procurements/{procurement}/accept',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SupplierProcurementController::accept
* @see app/Http/Controllers/SupplierProcurementController.php:157
* @route '/supplier/procurements/{procurement}/accept'
*/
accept.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { procurement: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            procurement: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        procurement: typeof args.procurement === 'object'
        ? args.procurement.id
        : args.procurement,
    }

    return accept.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierProcurementController::accept
* @see app/Http/Controllers/SupplierProcurementController.php:157
* @route '/supplier/procurements/{procurement}/accept'
*/
accept.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::accept
* @see app/Http/Controllers/SupplierProcurementController.php:157
* @route '/supplier/procurements/{procurement}/accept'
*/
const acceptForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: accept.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::accept
* @see app/Http/Controllers/SupplierProcurementController.php:157
* @route '/supplier/procurements/{procurement}/accept'
*/
acceptForm.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: accept.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

accept.form = acceptForm

/**
* @see \App\Http\Controllers\SupplierProcurementController::reject
* @see app/Http/Controllers/SupplierProcurementController.php:172
* @route '/supplier/procurements/{procurement}/reject'
*/
export const reject = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/supplier/procurements/{procurement}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SupplierProcurementController::reject
* @see app/Http/Controllers/SupplierProcurementController.php:172
* @route '/supplier/procurements/{procurement}/reject'
*/
reject.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { procurement: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            procurement: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        procurement: typeof args.procurement === 'object'
        ? args.procurement.id
        : args.procurement,
    }

    return reject.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierProcurementController::reject
* @see app/Http/Controllers/SupplierProcurementController.php:172
* @route '/supplier/procurements/{procurement}/reject'
*/
reject.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::reject
* @see app/Http/Controllers/SupplierProcurementController.php:172
* @route '/supplier/procurements/{procurement}/reject'
*/
const rejectForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::reject
* @see app/Http/Controllers/SupplierProcurementController.php:172
* @route '/supplier/procurements/{procurement}/reject'
*/
rejectForm.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

reject.form = rejectForm

/**
* @see \App\Http\Controllers\SupplierProcurementController::ship
* @see app/Http/Controllers/SupplierProcurementController.php:197
* @route '/supplier/procurements/{procurement}/ship'
*/
export const ship = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: ship.url(args, options),
    method: 'patch',
})

ship.definition = {
    methods: ["patch"],
    url: '/supplier/procurements/{procurement}/ship',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SupplierProcurementController::ship
* @see app/Http/Controllers/SupplierProcurementController.php:197
* @route '/supplier/procurements/{procurement}/ship'
*/
ship.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { procurement: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            procurement: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        procurement: typeof args.procurement === 'object'
        ? args.procurement.id
        : args.procurement,
    }

    return ship.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupplierProcurementController::ship
* @see app/Http/Controllers/SupplierProcurementController.php:197
* @route '/supplier/procurements/{procurement}/ship'
*/
ship.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: ship.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::ship
* @see app/Http/Controllers/SupplierProcurementController.php:197
* @route '/supplier/procurements/{procurement}/ship'
*/
const shipForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ship.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SupplierProcurementController::ship
* @see app/Http/Controllers/SupplierProcurementController.php:197
* @route '/supplier/procurements/{procurement}/ship'
*/
shipForm.patch = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ship.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

ship.form = shipForm

const SupplierProcurementController = { index, show, accept, reject, ship }

export default SupplierProcurementController