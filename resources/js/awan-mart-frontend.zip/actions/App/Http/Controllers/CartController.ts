import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
export const cart_view = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cart_view.url(options),
    method: 'get',
})

cart_view.definition = {
    methods: ["get","head"],
    url: '/cart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
cart_view.url = (options?: RouteQueryOptions) => {
    return cart_view.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
cart_view.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cart_view.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
cart_view.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cart_view.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
const cart_viewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart_view.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
cart_viewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart_view.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart_view
* @see app/Http/Controllers/CartController.php:23
* @route '/cart'
*/
cart_viewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart_view.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cart_view.form = cart_viewForm

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
export const cart_count = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cart_count.url(options),
    method: 'get',
})

cart_count.definition = {
    methods: ["get","head"],
    url: '/cart/count',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
cart_count.url = (options?: RouteQueryOptions) => {
    return cart_count.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
cart_count.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cart_count.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
cart_count.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cart_count.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
const cart_countForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart_count.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
cart_countForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart_count.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CartController::cart_count
* @see app/Http/Controllers/CartController.php:66
* @route '/cart/count'
*/
cart_countForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cart_count.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cart_count.form = cart_countForm

/**
* @see \App\Http\Controllers\CartController::cart_add
* @see app/Http/Controllers/CartController.php:144
* @route '/cart/item'
*/
export const cart_add = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cart_add.url(options),
    method: 'post',
})

cart_add.definition = {
    methods: ["post"],
    url: '/cart/item',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::cart_add
* @see app/Http/Controllers/CartController.php:144
* @route '/cart/item'
*/
cart_add.url = (options?: RouteQueryOptions) => {
    return cart_add.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart_add
* @see app/Http/Controllers/CartController.php:144
* @route '/cart/item'
*/
cart_add.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cart_add.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::cart_add
* @see app/Http/Controllers/CartController.php:144
* @route '/cart/item'
*/
const cart_addForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_add.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::cart_add
* @see app/Http/Controllers/CartController.php:144
* @route '/cart/item'
*/
cart_addForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_add.url(options),
    method: 'post',
})

cart_add.form = cart_addForm

/**
* @see \App\Http\Controllers\CartController::cart_update
* @see app/Http/Controllers/CartController.php:114
* @route '/cart/item/{cartItem}'
*/
export const cart_update = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cart_update.url(args, options),
    method: 'patch',
})

cart_update.definition = {
    methods: ["patch"],
    url: '/cart/item/{cartItem}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CartController::cart_update
* @see app/Http/Controllers/CartController.php:114
* @route '/cart/item/{cartItem}'
*/
cart_update.url = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cartItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cartItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cartItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cartItem: typeof args.cartItem === 'object'
        ? args.cartItem.id
        : args.cartItem,
    }

    return cart_update.definition.url
            .replace('{cartItem}', parsedArgs.cartItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart_update
* @see app/Http/Controllers/CartController.php:114
* @route '/cart/item/{cartItem}'
*/
cart_update.patch = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cart_update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\CartController::cart_update
* @see app/Http/Controllers/CartController.php:114
* @route '/cart/item/{cartItem}'
*/
const cart_updateForm = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::cart_update
* @see app/Http/Controllers/CartController.php:114
* @route '/cart/item/{cartItem}'
*/
cart_updateForm.patch = (args: { cartItem: number | { id: number } } | [cartItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

cart_update.form = cart_updateForm

/**
* @see \App\Http\Controllers\CartController::cart_add_bulk
* @see app/Http/Controllers/CartController.php:177
* @route '/cart/items/bulk'
*/
export const cart_add_bulk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cart_add_bulk.url(options),
    method: 'post',
})

cart_add_bulk.definition = {
    methods: ["post"],
    url: '/cart/items/bulk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CartController::cart_add_bulk
* @see app/Http/Controllers/CartController.php:177
* @route '/cart/items/bulk'
*/
cart_add_bulk.url = (options?: RouteQueryOptions) => {
    return cart_add_bulk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart_add_bulk
* @see app/Http/Controllers/CartController.php:177
* @route '/cart/items/bulk'
*/
cart_add_bulk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cart_add_bulk.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::cart_add_bulk
* @see app/Http/Controllers/CartController.php:177
* @route '/cart/items/bulk'
*/
const cart_add_bulkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_add_bulk.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::cart_add_bulk
* @see app/Http/Controllers/CartController.php:177
* @route '/cart/items/bulk'
*/
cart_add_bulkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_add_bulk.url(options),
    method: 'post',
})

cart_add_bulk.form = cart_add_bulkForm

/**
* @see \App\Http\Controllers\CartController::cart_delete
* @see app/Http/Controllers/CartController.php:91
* @route '/cart/items'
*/
export const cart_delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cart_delete.url(options),
    method: 'delete',
})

cart_delete.definition = {
    methods: ["delete"],
    url: '/cart/items',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CartController::cart_delete
* @see app/Http/Controllers/CartController.php:91
* @route '/cart/items'
*/
cart_delete.url = (options?: RouteQueryOptions) => {
    return cart_delete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CartController::cart_delete
* @see app/Http/Controllers/CartController.php:91
* @route '/cart/items'
*/
cart_delete.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cart_delete.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\CartController::cart_delete
* @see app/Http/Controllers/CartController.php:91
* @route '/cart/items'
*/
const cart_deleteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_delete.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CartController::cart_delete
* @see app/Http/Controllers/CartController.php:91
* @route '/cart/items'
*/
cart_deleteForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cart_delete.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

cart_delete.form = cart_deleteForm

const CartController = { cart_view, cart_count, cart_add, cart_update, cart_add_bulk, cart_delete }

export default CartController