import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
export const products = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: products.url(options),
    method: 'get',
})

products.definition = {
    methods: ["get","head"],
    url: '/admin/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
products.url = (options?: RouteQueryOptions) => {
    return products.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
products.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: products.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
products.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: products.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
const productsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: products.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
productsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: products.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::products
* @see app/Http/Controllers/AdminCatalogController.php:28
* @route '/admin/products'
*/
productsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: products.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

products.form = productsForm

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
export const createProduct = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createProduct.url(options),
    method: 'get',
})

createProduct.definition = {
    methods: ["get","head"],
    url: '/admin/products/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
createProduct.url = (options?: RouteQueryOptions) => {
    return createProduct.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
createProduct.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createProduct.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
createProduct.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createProduct.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
const createProductForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createProduct.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
createProductForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createProduct.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createProduct
* @see app/Http/Controllers/AdminCatalogController.php:74
* @route '/admin/products/create'
*/
createProductForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createProduct.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createProduct.form = createProductForm

/**
* @see \App\Http\Controllers\AdminCatalogController::storeProduct
* @see app/Http/Controllers/AdminCatalogController.php:108
* @route '/admin/products'
*/
export const storeProduct = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeProduct.url(options),
    method: 'post',
})

storeProduct.definition = {
    methods: ["post"],
    url: '/admin/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::storeProduct
* @see app/Http/Controllers/AdminCatalogController.php:108
* @route '/admin/products'
*/
storeProduct.url = (options?: RouteQueryOptions) => {
    return storeProduct.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::storeProduct
* @see app/Http/Controllers/AdminCatalogController.php:108
* @route '/admin/products'
*/
storeProduct.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeProduct.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::storeProduct
* @see app/Http/Controllers/AdminCatalogController.php:108
* @route '/admin/products'
*/
const storeProductForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeProduct.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::storeProduct
* @see app/Http/Controllers/AdminCatalogController.php:108
* @route '/admin/products'
*/
storeProductForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeProduct.url(options),
    method: 'post',
})

storeProduct.form = storeProductForm

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
export const editProduct = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editProduct.url(args, options),
    method: 'get',
})

editProduct.definition = {
    methods: ["get","head"],
    url: '/admin/products/{product}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
editProduct.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return editProduct.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
editProduct.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
editProduct.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editProduct.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
const editProductForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
editProductForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editProduct.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editProduct
* @see app/Http/Controllers/AdminCatalogController.php:83
* @route '/admin/products/{product}/edit'
*/
editProductForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editProduct.form = editProductForm

/**
* @see \App\Http\Controllers\AdminCatalogController::updateProduct
* @see app/Http/Controllers/AdminCatalogController.php:137
* @route '/admin/products/{product}'
*/
export const updateProduct = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProduct.url(args, options),
    method: 'put',
})

updateProduct.definition = {
    methods: ["put"],
    url: '/admin/products/{product}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::updateProduct
* @see app/Http/Controllers/AdminCatalogController.php:137
* @route '/admin/products/{product}'
*/
updateProduct.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return updateProduct.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::updateProduct
* @see app/Http/Controllers/AdminCatalogController.php:137
* @route '/admin/products/{product}'
*/
updateProduct.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProduct.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::updateProduct
* @see app/Http/Controllers/AdminCatalogController.php:137
* @route '/admin/products/{product}'
*/
const updateProductForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::updateProduct
* @see app/Http/Controllers/AdminCatalogController.php:137
* @route '/admin/products/{product}'
*/
updateProductForm.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateProduct.form = updateProductForm

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyProduct
* @see app/Http/Controllers/AdminCatalogController.php:194
* @route '/admin/products/{product}'
*/
export const destroyProduct = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyProduct.url(args, options),
    method: 'delete',
})

destroyProduct.definition = {
    methods: ["delete"],
    url: '/admin/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyProduct
* @see app/Http/Controllers/AdminCatalogController.php:194
* @route '/admin/products/{product}'
*/
destroyProduct.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return destroyProduct.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyProduct
* @see app/Http/Controllers/AdminCatalogController.php:194
* @route '/admin/products/{product}'
*/
destroyProduct.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyProduct.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyProduct
* @see app/Http/Controllers/AdminCatalogController.php:194
* @route '/admin/products/{product}'
*/
const destroyProductForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyProduct
* @see app/Http/Controllers/AdminCatalogController.php:194
* @route '/admin/products/{product}'
*/
destroyProductForm.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyProduct.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyProduct.form = destroyProductForm

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::categories
* @see app/Http/Controllers/AdminCatalogController.php:218
* @route '/admin/categories'
*/
categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: categories.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

categories.form = categoriesForm

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
export const createCategory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCategory.url(options),
    method: 'get',
})

createCategory.definition = {
    methods: ["get","head"],
    url: '/admin/categories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
createCategory.url = (options?: RouteQueryOptions) => {
    return createCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
createCategory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCategory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
createCategory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCategory.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
const createCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCategory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
createCategoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCategory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCategory
* @see app/Http/Controllers/AdminCatalogController.php:248
* @route '/admin/categories/create'
*/
createCategoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCategory.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCategory.form = createCategoryForm

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCategory
* @see app/Http/Controllers/AdminCatalogController.php:269
* @route '/admin/categories'
*/
export const storeCategory = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

storeCategory.definition = {
    methods: ["post"],
    url: '/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCategory
* @see app/Http/Controllers/AdminCatalogController.php:269
* @route '/admin/categories'
*/
storeCategory.url = (options?: RouteQueryOptions) => {
    return storeCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCategory
* @see app/Http/Controllers/AdminCatalogController.php:269
* @route '/admin/categories'
*/
storeCategory.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCategory
* @see app/Http/Controllers/AdminCatalogController.php:269
* @route '/admin/categories'
*/
const storeCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCategory.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCategory
* @see app/Http/Controllers/AdminCatalogController.php:269
* @route '/admin/categories'
*/
storeCategoryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCategory.url(options),
    method: 'post',
})

storeCategory.form = storeCategoryForm

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
export const editCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCategory.url(args, options),
    method: 'get',
})

editCategory.definition = {
    methods: ["get","head"],
    url: '/admin/categories/{category}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
editCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return editCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
editCategory.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCategory.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
editCategory.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCategory.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
const editCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCategory.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
editCategoryForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCategory.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCategory
* @see app/Http/Controllers/AdminCatalogController.php:256
* @route '/admin/categories/{category}/edit'
*/
editCategoryForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCategory.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCategory.form = editCategoryForm

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCategory
* @see app/Http/Controllers/AdminCatalogController.php:278
* @route '/admin/categories/{category}'
*/
export const updateCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

updateCategory.definition = {
    methods: ["put"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCategory
* @see app/Http/Controllers/AdminCatalogController.php:278
* @route '/admin/categories/{category}'
*/
updateCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return updateCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCategory
* @see app/Http/Controllers/AdminCatalogController.php:278
* @route '/admin/categories/{category}'
*/
updateCategory.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCategory
* @see app/Http/Controllers/AdminCatalogController.php:278
* @route '/admin/categories/{category}'
*/
const updateCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCategory.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCategory
* @see app/Http/Controllers/AdminCatalogController.php:278
* @route '/admin/categories/{category}'
*/
updateCategoryForm.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCategory.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCategory.form = updateCategoryForm

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCategory
* @see app/Http/Controllers/AdminCatalogController.php:285
* @route '/admin/categories/{category}'
*/
export const destroyCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

destroyCategory.definition = {
    methods: ["delete"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCategory
* @see app/Http/Controllers/AdminCatalogController.php:285
* @route '/admin/categories/{category}'
*/
destroyCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return destroyCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCategory
* @see app/Http/Controllers/AdminCatalogController.php:285
* @route '/admin/categories/{category}'
*/
destroyCategory.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCategory
* @see app/Http/Controllers/AdminCatalogController.php:285
* @route '/admin/categories/{category}'
*/
const destroyCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCategory.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCategory
* @see app/Http/Controllers/AdminCatalogController.php:285
* @route '/admin/categories/{category}'
*/
destroyCategoryForm.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCategory.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCategory.form = destroyCategoryForm

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
export const customers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customers.url(options),
    method: 'get',
})

customers.definition = {
    methods: ["get","head"],
    url: '/admin/customers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
customers.url = (options?: RouteQueryOptions) => {
    return customers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
customers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
customers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: customers.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
const customersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: customers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
customersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: customers.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::customers
* @see app/Http/Controllers/AdminCatalogController.php:298
* @route '/admin/customers'
*/
customersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: customers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

customers.form = customersForm

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
export const createCustomer = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCustomer.url(options),
    method: 'get',
})

createCustomer.definition = {
    methods: ["get","head"],
    url: '/admin/customers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
createCustomer.url = (options?: RouteQueryOptions) => {
    return createCustomer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
createCustomer.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCustomer.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
createCustomer.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCustomer.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
const createCustomerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCustomer.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
createCustomerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCustomer.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::createCustomer
* @see app/Http/Controllers/AdminCatalogController.php:337
* @route '/admin/customers/create'
*/
createCustomerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createCustomer.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createCustomer.form = createCustomerForm

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCustomer
* @see app/Http/Controllers/AdminCatalogController.php:360
* @route '/admin/customers'
*/
export const storeCustomer = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCustomer.url(options),
    method: 'post',
})

storeCustomer.definition = {
    methods: ["post"],
    url: '/admin/customers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCustomer
* @see app/Http/Controllers/AdminCatalogController.php:360
* @route '/admin/customers'
*/
storeCustomer.url = (options?: RouteQueryOptions) => {
    return storeCustomer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCustomer
* @see app/Http/Controllers/AdminCatalogController.php:360
* @route '/admin/customers'
*/
storeCustomer.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCustomer.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCustomer
* @see app/Http/Controllers/AdminCatalogController.php:360
* @route '/admin/customers'
*/
const storeCustomerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCustomer.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::storeCustomer
* @see app/Http/Controllers/AdminCatalogController.php:360
* @route '/admin/customers'
*/
storeCustomerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeCustomer.url(options),
    method: 'post',
})

storeCustomer.form = storeCustomerForm

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
export const editCustomer = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCustomer.url(args, options),
    method: 'get',
})

editCustomer.definition = {
    methods: ["get","head"],
    url: '/admin/customers/{customer}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
editCustomer.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return editCustomer.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
editCustomer.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCustomer.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
editCustomer.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCustomer.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
const editCustomerForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCustomer.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
editCustomerForm.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCustomer.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::editCustomer
* @see app/Http/Controllers/AdminCatalogController.php:345
* @route '/admin/customers/{customer}/edit'
*/
editCustomerForm.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: editCustomer.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

editCustomer.form = editCustomerForm

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCustomer
* @see app/Http/Controllers/AdminCatalogController.php:382
* @route '/admin/customers/{customer}'
*/
export const updateCustomer = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCustomer.url(args, options),
    method: 'put',
})

updateCustomer.definition = {
    methods: ["put"],
    url: '/admin/customers/{customer}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCustomer
* @see app/Http/Controllers/AdminCatalogController.php:382
* @route '/admin/customers/{customer}'
*/
updateCustomer.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return updateCustomer.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCustomer
* @see app/Http/Controllers/AdminCatalogController.php:382
* @route '/admin/customers/{customer}'
*/
updateCustomer.put = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCustomer.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCustomer
* @see app/Http/Controllers/AdminCatalogController.php:382
* @route '/admin/customers/{customer}'
*/
const updateCustomerForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCustomer.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::updateCustomer
* @see app/Http/Controllers/AdminCatalogController.php:382
* @route '/admin/customers/{customer}'
*/
updateCustomerForm.put = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateCustomer.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateCustomer.form = updateCustomerForm

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCustomer
* @see app/Http/Controllers/AdminCatalogController.php:402
* @route '/admin/customers/{customer}'
*/
export const destroyCustomer = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCustomer.url(args, options),
    method: 'delete',
})

destroyCustomer.definition = {
    methods: ["delete"],
    url: '/admin/customers/{customer}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCustomer
* @see app/Http/Controllers/AdminCatalogController.php:402
* @route '/admin/customers/{customer}'
*/
destroyCustomer.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return destroyCustomer.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCustomer
* @see app/Http/Controllers/AdminCatalogController.php:402
* @route '/admin/customers/{customer}'
*/
destroyCustomer.delete = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCustomer.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCustomer
* @see app/Http/Controllers/AdminCatalogController.php:402
* @route '/admin/customers/{customer}'
*/
const destroyCustomerForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCustomer.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminCatalogController::destroyCustomer
* @see app/Http/Controllers/AdminCatalogController.php:402
* @route '/admin/customers/{customer}'
*/
destroyCustomerForm.delete = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyCustomer.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyCustomer.form = destroyCustomerForm

const AdminCatalogController = { products, createProduct, storeProduct, editProduct, updateProduct, destroyProduct, categories, createCategory, storeCategory, editCategory, updateCategory, destroyCategory, customers, createCustomer, storeCustomer, editCustomer, updateCustomer, destroyCustomer }

export default AdminCatalogController