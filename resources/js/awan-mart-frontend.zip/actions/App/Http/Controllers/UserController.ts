import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UserController::address
* @see app/Http/Controllers/UserController.php:30
* @route '/user/address'
*/
export const address = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: address.url(options),
    method: 'post',
})

address.definition = {
    methods: ["post"],
    url: '/user/address',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::address
* @see app/Http/Controllers/UserController.php:30
* @route '/user/address'
*/
address.url = (options?: RouteQueryOptions) => {
    return address.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::address
* @see app/Http/Controllers/UserController.php:30
* @route '/user/address'
*/
address.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: address.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::address
* @see app/Http/Controllers/UserController.php:30
* @route '/user/address'
*/
const addressForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: address.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::address
* @see app/Http/Controllers/UserController.php:30
* @route '/user/address'
*/
addressForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: address.url(options),
    method: 'post',
})

address.form = addressForm

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::profile
* @see app/Http/Controllers/UserController.php:71
* @route '/profile'
*/
profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profile.form = profileForm

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:138
* @route '/profile'
*/
export const updateProfile = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile.url(options),
    method: 'put',
})

updateProfile.definition = {
    methods: ["put"],
    url: '/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:138
* @route '/profile'
*/
updateProfile.url = (options?: RouteQueryOptions) => {
    return updateProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:138
* @route '/profile'
*/
updateProfile.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:138
* @route '/profile'
*/
const updateProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::updateProfile
* @see app/Http/Controllers/UserController.php:138
* @route '/profile'
*/
updateProfileForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateProfile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateProfile.form = updateProfileForm

const UserController = { address, profile, updateProfile }

export default UserController